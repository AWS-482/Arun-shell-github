# Arun-shell-github
Devops shell scripting project 
# New to the Devops project
a= b+c
